export interface CategoryDTO {
  category_id: number;
  name: string;
  nicename: string;
}
